(* This function returns the count of the element in the list  *)
let rec findCount elem ls = 
 
   match ls with
        
      | [] -> 0    
      | (head::tail) -> if(head = elem) then (1 + (findCount elem tail)) else (findCount elem tail);;



(* This function returns the list after having deleted all occurences of the element *)

let rec delete x ls=
    match ls with
      | [] -> []
      | head::tail -> if (head = x) then (delete x tail) else ([head] @ (delete x tail));;

(*let deleter x ls = (delete (findIndex x ls) ls);;   *)

(* This function returns the pairs of element and count *)

let rec make_pairs ls =
     match ls with
       | []-> []
       | head::tail -> (head,(findCount head ls) ) :: (make_pairs (delete head ls)) ;;




