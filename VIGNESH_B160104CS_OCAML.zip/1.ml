


(* Checks whether element is present in the list*)
let rec find x l =
	match l with
	| [] -> false
	| (head::tail) -> if(head = x) then true else (find x tail);;


(* Returns the union of the two lists  *)
let rec union l1 l2 =
      match l1 with
      | [] -> l2
      | (head::tail) -> if(find head l2) then (union tail l2) else ([head]@(union tail l2));;


(* Returns the intersection of the two lists *)
let rec intersect list1 list2 =
     match list1 with
        
           | [] -> []
           | (head::tail) -> if(find head list2) then ([head] @(intersect tail list2)) else (intersect tail list2);;

