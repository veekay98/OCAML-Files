(* This function returns the position(not index) of the element in the list *)
let rec func x ls pos = match ls with
    | [] -> 0
    | head::tail -> if (head=x) then (pos + 1) else (func x tail (pos+1));;

let findIndex x ls = (func x ls 0);;

(* This function returns the list with the first occurence of the element deleted *)
let rec delete place ls=
    match ls with
      | [] -> []
      | head::tail -> if (head = (List.nth ls place)) then tail else ([head] @ (delete (place - 1) tail));;

let deleter x ls = (delete (findIndex x ls) ls);;